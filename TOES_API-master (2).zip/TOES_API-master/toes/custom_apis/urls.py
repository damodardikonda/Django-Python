from django.urls import path
from .views  import display_by_category, display_all

urlpatterns =[
    #Worker_Details
    path('category/<str:category>/', display_by_category ),
    path('allcategories/', display_all )
]