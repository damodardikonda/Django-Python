from django.apps import AppConfig


class CustomApisConfig(AppConfig):
    name = 'custom_apis'
