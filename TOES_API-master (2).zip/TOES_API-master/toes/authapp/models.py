from django.db import models
from django.contrib.auth.models import (
	BaseUserManager, AbstractBaseUser, AbstractUser
)


class User(AbstractUser):
    dob = models.DateField()
    email = models.EmailField(max_length=255)
    name = models.CharField(max_length = 255)
    phone = models.CharField(max_length=255,unique=True,blank=False)
    is_admin = models.BooleanField()
    gender = models.IntegerField(default=0)
    address = models.TextField(blank=False)
    smartphone = models.BooleanField(default = True)
    aadhar_no = models.CharField(max_length=255,default=None)
    profile_image = models.ImageField(default=None,upload_to='Profile_images/')
   
    REQUIRED_FIELDS = ['is_superuser','is_admin','name','username','password',
                        'dob','gender','aadhar_no', 'profile_image','email','address']

    USERNAME_FIELD = 'phone'

    def get_username(self):
        return self.phone

class Worker_Details(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    city = models.CharField(max_length=255,blank=True)
    category_1 = models.CharField(max_length=255,blank=True)
    category_1_vc = models.CharField(max_length=255,blank=True)
    category_1_exp = models.IntegerField(blank=True)
    category_2 = models.CharField(max_length=255,blank=True)
    category_2_vc = models.CharField(max_length=255,blank=True)
    category_2_exp = models.IntegerField(blank=True)
    category_3 = models.CharField(max_length=255,blank=True)
    category_3_vc = models.CharField(max_length=255,blank=True)
    category_3_exp = models.IntegerField(blank=True)


class Job_Details(models.Model):
    job_title = models.CharField(max_length=255)
    job_Description = models.CharField(max_length=300)
    recruter_id = models.IntegerField(blank=True)
    amount = models.IntegerField(blank=True)
    worker_id = models.IntegerField(blank=True)
    status = models.BooleanField(default=False)

class Categories(models.Model):
    categories_na = models.CharField(max_length=255,unique=True)
