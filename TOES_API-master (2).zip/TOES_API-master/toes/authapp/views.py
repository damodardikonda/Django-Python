from django.shortcuts import render
from rest_framework.decorators import api_view,permission_classes
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from .models import User, Worker_Details, Job_Details,Categories
from .serializers import UserCreateSerializer, WorkerDetailsSerializer, JobDetailsSerializer, CategoriesSerializer
from rest_framework import generics

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def restricted(request):

    return Response(data="Login Requied To Access This Page!", status=status.HTTP_200_OK)


#User 
class UserList(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    queryset = User.objects.all()
    serializer_class = UserCreateSerializer

class UserDetail(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAuthenticated]
    queryset = User.objects.all()
    serializer_class = UserCreateSerializer

#Worker_Details
class WorkerDetailsList(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    queryset = Worker_Details.objects.all()
    serializer_class = WorkerDetailsSerializer

class WorkerDetail(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAuthenticated]
    queryset = Worker_Details.objects.all()
    serializer_class = WorkerDetailsSerializer


#Job_Details
class JobDetailsList(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    queryset = Worker_Details.objects.all()
    serializer_class = JobDetailsSerializer

class JobDetail(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAuthenticated]
    queryset = Job_Details.objects.all()
    serializer_class = JobDetailsSerializer

#Categories
class CategoriesList(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    queryset = Categories.objects.all()
    serializer_class = CategoriesSerializer

class CategoriesDetail(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [IsAuthenticated]
    queryset = Categories.objects.all()
    serializer_class = CategoriesSerializer

