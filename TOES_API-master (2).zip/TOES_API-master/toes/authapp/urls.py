from django.urls import path,include
from . import views
urlpatterns = [

    path('',include('djoser.urls')),
    path('',include('djoser.urls.authtoken')),
    path('restricted/',views.restricted),
    
    #User
    path('user/', views.UserList.as_view()),
    path('userdetail/<int:pk>/', views.UserDetail.as_view()),
    
    #Worker_Details
    path('worker/', views.WorkerDetailsList.as_view()),
    path('workerdetail/<int:pk>/', views.WorkerDetail.as_view()),
    
    #Job_Detail
    path('job/', views.JobDetailsList.as_view()),
    path('jobdetail/<int:pk>/', views.JobDetail.as_view()),
    
    #Categories
    path('categories/', views.CategoriesList.as_view()),
    path('categoriesdetail/<int:pk>/', views.CategoriesDetail.as_view()),
    

    


]
