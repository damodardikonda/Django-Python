from django.contrib import admin
from . models import User,Worker_Details,Job_Details,Categories
# Register your models here.

admin.site.register(User)
admin.site.register(Worker_Details)
admin.site.register(Job_Details)
admin.site.register(Categories)
