data = [
    {
        "id": 1,
        "city": "Pune",
        "category_1": "painter",
        "category_1_vc": "100",
        "category_1_ex": 2,
        "category_2": "plumber",
        "category_2_vc": "100",
        "category_2_ex": 3,
        "category_3": "driver",
        "category_3_vc": "70",
        "category_3_ex": 3
    },
    {
        "id": 2,
        "city": "Pune",
        "category_1": "painter",
        "category_1_vc": "100",
        "category_1_ex": 0,
        "category_2": "Driver",
        "category_2_vc": "100",
        "category_2_ex": 4,
        "category_3": "electritian",
        "category_3_vc": "70",
        "category_3_ex": 5
    },
    {
        "id": 3,
        "city": "Pune",
        "category_1": "electrician",
        "category_1_vc": "100",
        "category_1_ex": 1,
        "category_2": "painter",
        "category_2_vc": "100",
        "category_2_ex": 2,
        "category_3": "driver",
        "category_3_vc": "70",
        "category_3_ex": 2
    },
    {
        "id": 5,
        "city": "Pune",
        "category_1": "painter",
        "category_1_vc": "100",
        "category_1_ex": 1,
        "category_2": "plumber",
        "category_2_vc": "100",
        "category_2_ex": 1,
        "category_3": "driver",
        "category_3_vc": "70",
        "category_3_ex": 2
    },
    {
        "id": 6,
        "city": "Pune",
        "category_1": "electrician",
        "category_1_vc": "100",
        "category_1_ex": 1,
        "category_2": "Driver",
        "category_2_vc": "100",
        "category_2_ex": 1,
        "category_3": "plumber",
        "category_3_vc": "70",
        "category_3_ex": 1
    },
    {
        "id": 7,
        "city": "Pune",
        "category_1": "electrician",
        "category_1_vc": "100",
        "category_1_ex": 1,
        "category_2": "Driver",
        "category_2_vc": "100",
        "category_2_ex": 1,
        "category_3": "plumber",
        "category_3_vc": "23",
        "category_3_ex": 1
    }
]

print(data[1])
for dictionary in data:
    for attributes, data in dictionary.items():
        if dictionary[attributes] == 'painter'