from django.urls import path,include
from . import views
urlpatterns = [

    path('',include('djoser.urls')),
    path('',include('djoser.urls.authtoken')),
    path('restricted/',views.restricted),
    #User
    path('UserList/', views.UserList.as_view()),
    path('UserDetail/<int:pk>/', views.UserDetail.as_view()),


]
