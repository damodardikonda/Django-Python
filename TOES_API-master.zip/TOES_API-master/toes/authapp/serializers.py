from djoser.serializers import UserCreateSerializer, UserSerializer
from .models import *
from rest_framework import generics

class UserCreateSerializer(UserCreateSerializer):
    class Meta(UserCreateSerializer.Meta):
        model = User
        fields = ('is_admin','id','email','username','password','name','phone','is_superuser')
