from django.db import models
from django.contrib.auth.models import (
	BaseUserManager, AbstractBaseUser, AbstractUser
)

class User(AbstractUser):
    email = models.EmailField(unique=True,max_length=255)
    name = models.CharField(max_length = 255)
    phone = models.CharField(null=True,max_length=255)
    is_admin = models.BooleanField()
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['is_superuser','is_admin','name','username','phone','password']
    

    def get_username(self):
        return self.email
